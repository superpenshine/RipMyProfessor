from django.apps import AppConfig


class RipConfig(AppConfig):
    name = 'rip'
